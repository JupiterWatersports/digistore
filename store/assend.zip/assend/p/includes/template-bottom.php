<?php
/* 
  template-bottom.php - OSC to CSS v2.0 Sept 2010
  Released under the GNU General Public License
  OSC to CSS v2.0 http://www.niora.com/css-oscommerce.php
*/
?>


</div>
<!-- close content -->
<div class="clear"></div>
</div>
<div class="clear"></div>
	<?php require(DIR_WS_INCLUDES . 'footer.php'); ?>
<!--close grid container-->

<?php
//end file
?>
</body>
</html>