<!-- // BOF MaxiDVD: Modified For Ultimate Images Pack! //-->
<div class="selectors row" style="text-align:center; margin-top:10px;">


<?php
    if (($product_info['products_image_sm_1'] != '') && ($product_info['products_image_xl_1'] != '')) {
	 if (($product_info['products_image_zoom_1'] != '')) {	
	    
 echo '<a data-zoom-id="Zoom-1" href="' . DIR_WS_IMAGES . $product_info['products_image_zoom_1'] . '" data-image="' . DIR_WS_IMAGES . $product_info['products_image_xl_1'] . '">' . '<img style="height:65px; width=:65px;" srcset="'.DIR_WS_IMAGES . $product_info['products_image_xl_1'].' 2x" src="'.DIR_WS_IMAGES . $product_info['products_image_sm_1'].'?scale.width=56" "></a>'; 
    } else { echo '<a data-zoom-id="Zoom-1" href="' . DIR_WS_IMAGES . $product_info['products_image_xl_1'] . '" data-image="' . DIR_WS_IMAGES . $product_info['products_image_xl_1'] . '">' . '<img style="height:65px; width=:65px;" srcset="'.DIR_WS_IMAGES . $product_info['products_image_xl_1'].' 2x" src="'.DIR_WS_IMAGES . $product_info['products_image_sm_1'].'?scale.width=56" "></a>';}

    } else {echo '';}
?>

<?php
    if (($product_info['products_image_sm_2'] != '') && ($product_info['products_image_xl_2'] != '')) {
	 if (($product_info['products_image_zoom_2'] != '')) {	
	    
 echo '<a data-zoom-id="Zoom-1" href="' . DIR_WS_IMAGES . $product_info['products_image_zoom_2'] . '" data-image="' . DIR_WS_IMAGES . $product_info['products_image_xl_2'] . '">' . '<img style="height:65px; width=:65px;" srcset="'.DIR_WS_IMAGES . $product_info['products_image_xl_2'].' 2x" src="'.DIR_WS_IMAGES . $product_info['products_image_sm_2'].'?scale.width=56" "></a>'; 
    } else { echo '<a data-zoom-id="Zoom-1" href="' . DIR_WS_IMAGES . $product_info['products_image_xl_2'] . '" data-image="' . DIR_WS_IMAGES . $product_info['products_image_xl_2'] . '">' . '<img style="height:65px; width=:65px;" srcset="'.DIR_WS_IMAGES . $product_info['products_image_xl_2'].' 2x" src="'.DIR_WS_IMAGES . $product_info['products_image_sm_2'].'?scale.width=56" "></a>';}

    } else {echo '';}
?>

<?php
    if (($product_info['products_image_sm_3'] != '') && ($product_info['products_image_xl_3'] != '')) {
	 if (($product_info['products_image_zoom_3'] != '')) {	
	    
 echo '<a data-zoom-id="Zoom-1" href="' . DIR_WS_IMAGES . $product_info['products_image_zoom_3'] . '" data-image="' . DIR_WS_IMAGES . $product_info['products_image_xl_3'] . '">' . '<img style="height:65px; width=:65px;" srcset="'.DIR_WS_IMAGES . $product_info['products_image_xl_3'].' 2x" src="'.DIR_WS_IMAGES . $product_info['products_image_sm_3'].'?scale.width=56" "></a>'; 
    } else { echo '<a data-zoom-id="Zoom-1" href="' . DIR_WS_IMAGES . $product_info['products_image_xl_3'] . '" data-image="' . DIR_WS_IMAGES . $product_info['products_image_xl_3'] . '">' . '<img style="height:65px; width=:65px;" srcset="'.DIR_WS_IMAGES . $product_info['products_image_xl_3'].' 2x" src="'.DIR_WS_IMAGES . $product_info['products_image_sm_3'].'?scale.width=56" "></a>';}

    } else {echo '';}
?>

<?php
    if (($product_info['products_image_sm_4'] != '') && ($product_info['products_image_xl_4'] != '')) {
	 if (($product_info['products_image_zoom_4'] != '')) {	
	    
 echo '<a data-zoom-id="Zoom-1" href="' . DIR_WS_IMAGES . $product_info['products_image_zoom_4'] . '" data-image="' . DIR_WS_IMAGES . $product_info['products_image_xl_4'] . '">' . '<img style="height:65px; width=:65px;" srcset="'.DIR_WS_IMAGES . $product_info['products_image_xl_4'].' 2x" src="'.DIR_WS_IMAGES . $product_info['products_image_sm_4'].'?scale.width=56" "></a>'; 
    } else { echo '<a data-zoom-id="Zoom-1" href="' . DIR_WS_IMAGES . $product_info['products_image_xl_4'] . '" data-image="' . DIR_WS_IMAGES . $product_info['products_image_xl_4'] . '">' . '<img style="height:65px; width=:65px;" srcset="'.DIR_WS_IMAGES . $product_info['products_image_xl_4'].' 2x" src="'.DIR_WS_IMAGES . $product_info['products_image_sm_4'].'?scale.width=56" "></a>';}

    } else {echo '';}
?>


<?php
    if (($product_info['products_image_sm_5'] != '') && ($product_info['products_image_xl_5'] != '')) {
	 if (($product_info['products_image_zoom_5'] != '')) {	
	    
 echo '<a data-zoom-id="Zoom-1" href="' . DIR_WS_IMAGES . $product_info['products_image_zoom_5'] . '" data-image="' . DIR_WS_IMAGES . $product_info['products_image_xl_5'] . '">' . '<img style="height:65px; width=:65px;" srcset="'.DIR_WS_IMAGES . $product_info['products_image_xl_5'].' 2x" src="'.DIR_WS_IMAGES . $product_info['products_image_sm_5'].'?scale.width=56" "></a>'; 
    } else { echo '<a data-zoom-id="Zoom-1" href="' . DIR_WS_IMAGES . $product_info['products_image_xl_5'] . '" data-image="' . DIR_WS_IMAGES . $product_info['products_image_xl_5'] . '">' . '<img style="height:65px; width=:65px;" srcset="'.DIR_WS_IMAGES . $product_info['products_image_xl_5'].' 2x" src="'.DIR_WS_IMAGES . $product_info['products_image_sm_5'].'?scale.width=56" "></a>';}

    } else {echo '';}
?>


<?php
    if (($product_info['products_image_sm_6'] != '') && ($product_info['products_image_xl_6'] != '')) {
	 if (($product_info['products_image_zoom_6'] != '')) {	
	    
 echo '<a data-zoom-id="Zoom-1" href="' . DIR_WS_IMAGES . $product_info['products_image_zoom_6'] . '" data-image="' . DIR_WS_IMAGES . $product_info['products_image_xl_6'] . '">' . '<img style="height:65px; width=:65px;" srcset="'.DIR_WS_IMAGES . $product_info['products_image_xl_6'].' 2x" src="'.DIR_WS_IMAGES . $product_info['products_image_sm_6'].'?scale.width=56" "></a>'; 
    } else { echo '<a data-zoom-id="Zoom-1" href="' . DIR_WS_IMAGES . $product_info['products_image_xl_6'] . '" data-image="' . DIR_WS_IMAGES . $product_info['products_image_xl_6'] . '">' . '<img style="height:65px; width=:65px;" srcset="'.DIR_WS_IMAGES . $product_info['products_image_xl_6'].' 2x" src="'.DIR_WS_IMAGES . $product_info['products_image_sm_6'].'?scale.width=56" "></a>';}

    } else {echo '';}
?>

</div>
<!-- // BOF MaxiDVD: Modified For Ultimate Images Pack! //-->
