<?php
/*
  $Id: article_reviews.php, v1.0 2003/12/04 12:00:00 ra Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Reviews of ');
define('NAVBAR_TITLE', 'Reviews');

define('TEXT_NO_ARTICLE_REVIEWS', 'There are currently no aproved reviews for this article.');
define('TEXT_OF_5_STARS', '%s out of 5 Stars');
define('TEXT_REVIEW_VIEWS', 'Number of times read: ');
define('TEXT_READ_REVIEW', 'Read Review...');

?>
