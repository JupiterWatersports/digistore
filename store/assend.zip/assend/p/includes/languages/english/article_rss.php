<?php
/*
  $Id: index.php,v 1.1 2003/06/11 17:38:00 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/
define('NEWS_TITLE', 'RSS Articles Feed');
define('NEWS_DESCRIPTION', 'Articles for '.STORE_NAME);

?>
