<?php
/*
  $Id: article_reviews_write.php, v1.0 2003/12/04 12:00:00 ra Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Reviews');
define('HEADING_TITLE', 'Write Review of \'');

define('SUB_TITLE_FROM', 'From:');
define('SUB_TITLE_REVIEW', 'Your Review:');
define('SUB_TITLE_RATING', 'Rating:');

define('TEXT_APPROVAL_WARNING', 'Note: Your review will not appear until it has been approved.');
define('TEXT_BAD', '<small><font color="#ff0000"><b>Poor</b></font></small>');
define('TEXT_GOOD', '<small><font color="#ff0000"><b>Excellent</b></font></small>');

?>
