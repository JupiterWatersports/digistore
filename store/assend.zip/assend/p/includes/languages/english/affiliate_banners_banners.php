<?php
/*
  $Id: affiliate_banners_banners.php,v 2.00 2003/10/12

  OSC-Affiliate

  Contribution based on:

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 - 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Affiliate Program');
define('HEADING_TITLE', 'Affiliate Program - Banners');

define('TEXT_AFFILIATE_NAME', 'Banner Name:');
define('TEXT_INFORMATION', 'Choose the banner you want to display on your website from the choices below:');
define('TEXT_AFFILIATE_INFO', 'Copy the code shown below and paste into your website');
?>