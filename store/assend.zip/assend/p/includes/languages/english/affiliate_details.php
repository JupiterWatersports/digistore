<?php
/*
  $Id: affiliate_details.php,v 2.00 2003/10/12

  OSC-Affiliate

  Contribution based on:

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 - 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE_1', 'The Affiliate Program');
define('NAVBAR_TITLE_2', 'Edit Affiliate Account');
define('HEADING_TITLE', 'The Affiliate Program - Your Account Details<br /><small>You may edit any information below:</small>');
?>