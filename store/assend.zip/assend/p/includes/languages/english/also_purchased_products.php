<?php
/*
  $Id: products_new.php 1739 2007-12-20 00:52:16Z hpdl $

  Digistore v4.0,  Open Source E-Commerce Solutions
  http://www.digistore.co.nz

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'New Products');
define('HEADING_TITLE', 'New Products');

define('TEXT_DATE_ADDED', 'Date Added:');
define('TEXT_MANUFACTURER', 'Manufacturer:');
define('TEXT_PRICE', '');
?>