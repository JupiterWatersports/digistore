<?php
/*
  $Id: product_print.php, 2006/06/06 01:48:08 dgw_ Exp $
   
   ============================================  
   DIGISTORE FREE ECOMMERCE OPEN SOURCE VER 3.2  
   ============================================
      
   (c)2005-2006
   The Digistore Developing Team NZ   
   http://www.digistore.co.nz                       
                                                                                           
   SUPPORT & PROJECT UPDATES:                                  
   http://www.digistore.co.nz/support/
   
   Portions Copyright (c) 2003 osCommerce, http://www.oscommerce.com
   http://www.digistore.co.nz   
   
   This software is released under the
   GNU General Public License. A copy of
   the license is bundled with this
   package.   
   
   No warranty is provided on the open
   source version of this software.
   
   ========================================
*/

define('DIGISTORE_INFORMATION', '<a href="http://www.digistore.co.nz">Powered by Digistore Ecommerce</A>');

define('TITLE_PRINT', 'Print Page');
define('TITLE_CLOSE', 'Close Window');
?>
