<?php 
// /catalog/includes/languages/[language]/extraheader.php
// in english.php require(DIR_WS_LANGUAGES . $language . '/' . 'extraheader.php');
?>
      <table  BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH=100%>
                    <tr class="headerNavigation" valign=middle align=left style="background:#E5E5E5">

<td width="14%" height="28" class="headerNavigation" style="padding-left:5px;"><a class="headerNavigation" href="http://jupiterkiteboarding.com/store/kiteboarding-c-611.html">Kiteboarding</a></td>

<td width="16%" class="headerNavigation"><a class="headerNavigation" href="http://jupiterkiteboarding.com/store/paddleboarding-c-612.html">Paddleboarding</a></td>

<td width="15%" class="headerNavigation"><a class="headerNavigation" href="http://jupiterkiteboarding.com/store/wakeboarding-c-200.html">Wakeboarding</a></td>

<td width="8%" class="headerNavigation"><a class="headerNavigation" href="http://jupiterkiteboarding.com/store/gopro-c-551.html">GoPro</a></td>

<td width="13%" class="headerNavigation"><a class="headerNavigation" href="http://jupiterkiteboarding.com/store/water-wear-c-67.html">Water Wear</a></td>

<td width="13%" class="headerNavigation"><a class="headerNavigation" href="http://jupiterkiteboarding.com/store/windsurfing-c-549.html">Windsurfing</a></td>

<td width="13%" class="headerNavigation"><a class="headerNavigation" href="http://jupiterkiteboarding.com/store/skate-balance-boards-c-582.html">Long Boards</a></td>

<td width="8%" class="headerNavigation"><a class="headerNavigation" href="http://jupiterkiteboarding.com/store/surfing-c-627.html">Surfing</a></td>
                    </tr>
</table>