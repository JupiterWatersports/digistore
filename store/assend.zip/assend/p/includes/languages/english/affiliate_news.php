<?php
/*
  $Id: affiliate_banners.php,v 2.10 2003/10/12

  OSC-Affiliate

  Contribution based on:

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 - 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Affiliate Program');
define('HEADING_TITLE', 'Affiliate News');
define('TABLE_HEADING_AFFILIATE_NEWS', 'Affiliate News');
//add on \admin\includes\english\affiliate_news.php
// npe admin begin #add
define('TEXT_AFFILIATE_NEWS_CONTENT_DELETE', 'Delete displayed news in this language!');
define('EMPTY_CATEGORY', 'Empty news');
define('TEXT_NO_CHILD_CATEGORIES_OR_PRODUCTS', 'There are no news which can be displayed to your affiliate partners.');
// npe admin begin #add

?>
