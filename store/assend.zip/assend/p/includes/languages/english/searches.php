<?php
define('SUGGESTED_PRODUCTS', 'Suggested products');
define('SUGGESTED_CATEGORIES', 'Suggested categories');
define('MORE_RESULTS_1', '&nbsp;<strong>This search has more reults, please click here to view them all.</strong>');
define('MORE_RESULTS_2', ' <strong>More Results, please click here.</strong>');
define('BUY_NOW', '<b>(Buy Now)</b>');
define('NO_RESULTS_FOUND', '&nbsp;No Results Found');
define('ADVANCED_SEARCH', '<strong>Try our advanced search</strong>');
?>
