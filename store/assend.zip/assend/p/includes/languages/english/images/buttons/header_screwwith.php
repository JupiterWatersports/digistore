<style>
body {
}
</style>

<body>
<table border="0" width="100%" cellspacing="0" cellpadding="1">
  <tr class="headerNavigation">
    <td align="right" height="15" style="padding:0px 10px 0px 10px; color: #3879C8;" bgcolor='#E5E5E5'>	 <span class="headerNavigationtop"><a href="https://www.jupiterkiteboarding.com/store/account.php" class="headerNavigationtop">My Account</a> &nbsp;|&nbsp; <a href="http://jupiterkiteboarding.com/store/shopping_cart.php" class="headerNavigationtop">Cart Contents</a> &nbsp;|&nbsp; <a href="https://www.jupiterkiteboarding.com/store/checkout_shipping.php" class="headerNavigationtop">Checkout</a> &nbsp; | &nbsp;<a href="http://jupiterkiteboarding.com/store/specials.php" class="headerNavigationtop">Specials</a> 
    &nbsp; | &nbsp;<a href="http://jupiterkiteboarding.com/store/products_new.php" class="headerNavigationtop">New Products</a> &nbsp; | &nbsp;<a href="http://jupiterkiteboarding.com/store/advanced_search.php" class="headerNavigationtop">Search</a>&nbsp; | &nbsp;<a href="https://www.jupiterkiteboarding.com/store/contact_us.php" class="headerNavigationtop">Contact us</a>&nbsp; | &nbsp;<a href="http://jupiterkiteboarding.com/store/tracking.php" class="headerNavigationtop">Order Tracking</a>&nbsp; |</span></td>
</tr>

</table>
<table border="0" width="100%" cellspacing="0" cellpadding="0">
  <tr class="header2">
    <td height="65" valign="middle"><img src="images/summerlogo4.jpg" width="288" height="120"></td>
<td><img src="store/images/banners/products_shoppingcart2.gif" width="718" height="112"></a></td>  </tr>
</table>

<table  BORDER=0 CELLSPACING=0 CELLPADDING=0 WIDTH=100%>
                    <tr class="headerNavigation" valign=middle align=left style="background:#E5E5E5">

<td width="14%" height="28" class="headerNavigation" style="padding-left:5px;"><a class="headerNavigation" href="http://jupiterkiteboarding.com/store/kiteboarding-c-611.html">Kiteboarding</a></td>

<td width="16%" class="headerNavigation"><a class="headerNavigation" href="http://jupiterkiteboarding.com/store/paddleboarding-c-612.html">Paddleboarding</a></td>

<td width="14%" class="headerNavigation"><a class="headerNavigation" href="http://jupiterkiteboarding.com/store/wakeboarding-c-200.html">Wakeboarding</a></td>

<td width="9%" class="headerNavigation"><a class="headerNavigation" href="http://jupiterkiteboarding.com/store/gopro-c-551.html">GoPro</a></td>

<td width="13%" class="headerNavigation"><a class="headerNavigation" href="http://jupiterkiteboarding.com/store/water-wear-c-67.html">Water Wear</a></td>

<td width="13%" class="headerNavigation"><a class="headerNavigation" href="http://jupiterkiteboarding.com/store/windsurfing-c-549.html">Windsurfing</a></td>

<td width="13%" class="headerNavigation"><a class="headerNavigation" href="http://jupiterkiteboarding.com/store/skate-balance-boards-c-582.html">Long Boards</a></td>

<td width="8%" class="headerNavigation"><a class="headerNavigation" href="http://jupiterkiteboarding.com/store/surfing-c-627.html">Surfing</a></td>
                    </tr>
</table><table border="0" width="100%" cellspacing="0" cellpadding="0">
<tr class="headerCrumb">
    <td height="28" class="headerCrumb" valign="middle" style="padding:0px 10px 0px 2px">&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://jupiterkiteboarding.com" class="headerCrumb">Home</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://jupiterkiteboarding.com/weather.php" class="headerCrumb">Weather</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="http://jupiterkiteboarding.com/safekiteboarding.php" class="headerCrumb">Safety Guidelines</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="shipping2.php" class="headerCrumb">Free Shipping On Orders Over $100</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="gallery.php" class="headerCrumb">Gallery</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
      <select name="mp_id" onChange="this.form.submit();" size="1" max length="30" style="width: 150px">
        <option value="" selected>Select Manufacturer</option>
        <option value="53">AirTime</option>
        <option value="68">Airush</option>
        <option value="65">Alex Aguera</option>
        <option value="89">Amsteel</option>
        <option value="72">Aquaglide</option>
        <option value="106">Aquapac</option>
        <option value="112">Arbor</option>
        <option value="77">Banshee Bungee</option>
        <option value="73">Bic SUP</option>
        <option value="56">BoardFisher</option>
        <option value="37">C4 Waterman</option>
        <option value="10">Cabrinha</option>
        <option value="78">Chinook</option>
        <option value="16">Crazy Fly</option>
        <option value="21">Dakine</option>
        <option value="62">Ding All</option>
        <option value="86">Doc Martin&#039;s</option>
        <option value="115">DocksLocks</option>
        <option value="49">Dry Case</option>
        <option value="110">Ez Kine</option>
        <option value="88">Fibre Glas Fin ..</option>
        <option value="52">Fix My Kite</option>
        <option value="121">Futures</option>
        <option value="59">Gatekeeper</option>
        <option value="46">Gath</option>
        <option value="38">Global Surf</option>
        <option value="61">GoPro</option>
        <option value="99">High Surf Acces..</option>
        <option value="75">Hobie</option>
        <option value="95">Indo</option>
        <option value="118">ION</option>
        <option value="20">Jimmy Lewis</option>
        <option value="85">Jupiter</option>
        <option value="105">Kaenon</option>
        <option value="71">Kahuna Creation..</option>
        <option value="81">King Surf Hawai..</option>
        <option value="51">Kite Fix</option>
        <option value="67">Kite Hero</option>
        <option value="109">Lift SUP</option>
        <option value="23">Liquid Force</option>
        <option value="47">Litewave</option>
        <option value="63">MBS</option>
        <option value="108">Mike Waltz Film..</option>
        <option value="57">Mule Transport ..</option>
        <option value="117">Mustang</option>
        <option value="42">Mystic</option>
        <option value="30">Naish</option>
        <option value="18">Nobile</option>
        <option value="11">North</option>
        <option value="39">NPX</option>
        <option value="43">NSI</option>
        <option value="74">NSP</option>
        <option value="54">OAM</option>
        <option value="91">Ocean Eyes</option>
        <option value="87">Ocean Potion</option>
        <option value="29">Ozone</option>
        <option value="116">Penny</option>
        <option value="96">Peter Grimm</option>
        <option value="104">PFD In A Bag</option>
        <option value="111">Powerline Sport..</option>
        <option value="26">Premier</option>
        <option value="60">Pro Kite Surf</option>
        <option value="48">Pro-tec</option>
        <option value="92">Progression</option>
        <option value="84">Prolimit</option>
        <option value="40">Quickblade</option>
        <option value="114">Rack-it-Up</option>
        <option value="69">Rainbow Fin Com..</option>
        <option value="97">Rainbow Sandals</option>
        <option value="64">Riviera Paddles..</option>
        <option value="13">RRD</option>
        <option value="102">SBC Kiteboard M..</option>
        <option value="44">Sea Specs</option>
        <option value="82">Sean Ordonez</option>
        <option value="50">Shapers</option>
        <option value="58">Skywatch</option>
        <option value="12">Slingshot</option>
        <option value="107">Sticky Bumps</option>
        <option value="119">Straight Line</option>
        <option value="113">SUP WHeels</option>
        <option value="55">Surf Co. Hawaii</option>
        <option value="120">Surf Nano Produ..</option>
        <option value="45">Surf Shades</option>
        <option value="34">Surftech</option>
        <option value="80">Tahoe</option>
        <option value="70">Thule</option>
        <option value="66">ULI</option>
        <option value="19">Underground</option>
        <option value="94">VewDo</option>
        <option value="35">Wainman Hawaii</option>
        <option value="83">Walden</option>
        <option value="36">Werner</option>
        <option value="98">West</option>
        <option value="79">Yakima</option>
        <option value="33">YOLO</option>
      </select>
      <form name="manufacturers" action="http://jupiterkiteboarding.com/store/index.php" method="get">
      </form>

      <!-- manufacturers //-->
    <tr>
     <table cellpadding="0" cellspacing="0" border="0"><tr><td valign="right"> 	
                     <!-- search_box_oef //-->
					<form name="quick_find" action="http://jupiterkiteboarding.com/store/advanced_search_result.php" method="get"><input type="hidden" name="search_in_description" value="1"><input type="text" name="keywords" size="10" maxlength="30" style="width: 135px; height:20px; font-size:12px;" onClick="this.value=''"><td  style="vertical-align: top; padding:0px 0px 0px 10px;"><input type="image" src="store/includes/languages/english/images/buttons/button_quick_find.gif" border="0" alt="Quick Find" title=" Quick Find "></a></form></tr></table>
  </tr>  
  </tr>
</table>
<!-- manufacturers_eof //-->
<td class="boxText"></td>
  </tr>
                  
</table>

  </tr>
</table>