<?php
/*
  $Id: reviews.php 1739 2007-12-20 00:52:16Z hpdl $

  Digistore v4.0,  Open Source E-Commerce Solutions
  http://www.digistore.co.nz

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Reviews');
define('HEADING_TITLE', 'Find out what gear our watermen endorse and why. Here you can find detailed honest reviews on the latest gear.  We our commited to selling gear that our customers can rely on.  Contact our support staff for any additional information at 561-427-0240 or info@jupiterkiteboarding.com');
define('TEXT_OF_5_STARS', '%s out of 5');
?>