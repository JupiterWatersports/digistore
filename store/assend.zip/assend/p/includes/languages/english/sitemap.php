<?php
/*
  $Id: sitemap.php,v1.0 2004/05/10 hpdl Exp $

  Digistore v4.0,  Open Source E-Commerce Solutions
  http://www.digistore.co.nz

  Copyright � 2004 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Site Map');
define('HEADING_TITLE', 'Site Map');

define('PAGE_ACCOUNT', 'My Account');
define('PAGE_ACCOUNT_EDIT', 'Account Information');
define('PAGE_ADDRESS_BOOK', 'Address Book');
define('PAGE_ACCOUNT_HISTORY', 'Order History');
define('PAGE_ACCOUNT_NOTIFICATIONS', 'Newsletter Subscriptions');
define('PAGE_SHOPPING_CART', 'Shopping Cart');
define('PAGE_CHECKOUT_SHIPPING', 'Checkout');
define('PAGE_ADVANCED_SEARCH', 'Advanced Search');
define('PAGE_PRODUCTS_NEW', 'New Products');
define('PAGE_SPECIALS', 'Specials');
define('PAGE_REVIEWS', 'Reviews');
?>