<?php
/*
  $Id: article-topics.php, v1.0 2003/12/04 12:00:00 ra Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_ARTICLE_TOPICS', 'All Article Topics');
define('TEXT_ARTICLE_TOPICS_NOT_FOUND', 'No topics can be found.');
define('TEXT_MAIN', '');

 

?>
