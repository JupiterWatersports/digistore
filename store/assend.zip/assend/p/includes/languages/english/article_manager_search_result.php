<?php
/*
  $Id: article_manager_search_result.php,v 1.4 2002/11/19 01:48:08 dgw_ Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Article Manager Search Result');
define('HEADING_TITLE', 'Article Manager Search Result');

define('TEXT_INFORMATION', 'Articles Search results');
define('TEXT_NO_ARTICLES_FOUND', 'No articles were found that matched the search criteria.');
define('TEXT_SEARCH_SEE_MORE', '<span style="color:red">...more</span>');
?>
