<?php
/*
  $Id: affiliate_contact.php,v 2.00 2003/10/12

  OSC-Affiliate

  Contribution based on:

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 - 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Affiliate Program');
define('HEADING_TITLE', 'Affiliate Program - Contact Form');

define('TEXT_SUCCESS', 'Your message has been successfully sent to the Affiliate Program Team');

define('EMAIL_SUBJECT', 'Affiliate Program');
define('ENTRY_NAME', 'Your Full Name:');
define('ENTRY_EMAIL', 'Your E-Mail:');
define('ENTRY_ENQUIRY', 'Your Message:');
?>