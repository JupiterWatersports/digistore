<?php
/*
  $Id: affiliate_payment.php,v 2.00 2003/10/12

  OSC-Affiliate

  Contribution based on:

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 - 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Affiliate Program');
define('HEADING_TITLE', 'Affiliate Program: Payment');

define('TEXT_AFFILIATE_HEADER', 'Your Payments:');

define('TABLE_HEADING_DATE', 'Payment Date');
define('TABLE_HEADING_PAYMENT', 'Affiliate Earnings');
define('TABLE_HEADING_STATUS', 'Payment Status');
define('TABLE_HEADING_PAYMENT_ID','Payment-ID');
define('TEXT_DISPLAY_NUMBER_OF_PAYMENTS', 'Displaying <b>%d</b> to <b>%d</b> (of <b>%d</b> payments)');
define('TEXT_INFORMATION_PAYMENT_TOTAL', 'Your current earnings amount to:');
define('TEXT_NO_PAYMENTS', 'No payments have been recorded yet.');

define('TEXT_PAYMENT_HELP', ' <font color="#FFFFFF">[?]</font>');
define('TEXT_PAYMENT', 'Click on [?] to see a description of each category.');
define('HEADING_PAYMENT_HELP', 'Affiliate Help');
define('TEXT_DATE_HELP', '<i>Date</i> represents the date of the payment made to the affiliate.');
define('TEXT_PAYMENT_ID_HELP', '<i>Payment-ID</i> represents the payment number associated to the payment.');
define('TEXT_PAYMENT_HELP', '<i>Affiliate Earnings</i> represents the value of payment made to the affiliate.');
define('TEXT_STATUS_HELP', '<i>Payment Status</i> represents the status of the payment made to the affiliate');
define('TEXT_CLOSE_WINDOW', 'Close Window [x]');
?>