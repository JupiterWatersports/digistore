<?php
/*
  $Id: comparison.php 1.1 20101027 kymation $
  $Loc: catalog/includes/languages/english/ $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2009 osCommerce

  Released under the GNU General Public License
*/

  define ('HEADING_TITLE', '%s Comparison');

  define ('TEXT_NO_COMPARISON_AVAILABLE', 'Sorry, the comparison page for these products is not currently available.');
  define ('TEXT_NOT_AVAILABLE', 'N/A');
  define ('TEXT_PRODUCT', 'Product');
?>
