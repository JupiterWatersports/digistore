<?php
/*
  $Id: account_validation.php,v 2.1a 2004/08/10 20:19:27 chaicka Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2004 osCommerce

  Released under the GNU General Public License
*/

  define('CATEGORY_ANTIROBOTREG', 'Validation Code');

  define('ENTRY_ANTIROBOTREG', 'For the security of your information,<br />please enter the characters in the grey box<br /><i>This helps prevent automated processes</i>');
  define('ENTRY_ANTIROBOTREG_TEXT', '&nbsp;<small><font color="FF0000">*</font></small>');

  define('RELOAD', 'Re-arrange Code');

  define('VALIDATED', '<big>&nbsp;Validated, thankyou</big>');
	
  define('ERROR_VALIDATION', 'Error:');
  define('ERROR_VALIDATION_1', 'Could not obtain registration information');
  define('ERROR_VALIDATION_2', 'Invalid Validation Code');
  define('ERROR_VALIDATION_3', 'Could not delete validation key');
  define('ERROR_VALIDATION_4', 'Could not optimize database');
  define('ERROR_VALIDATION_5', 'Could not check registration information');
?>