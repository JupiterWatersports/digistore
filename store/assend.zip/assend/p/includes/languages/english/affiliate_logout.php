<?php
/*
  $Id: affiliate_logout.php,v 2.00 2003/10/12

  OSC-Affiliate

  Contribution based on:

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 - 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'The Affiliate Program');
define('HEADING_TITLE', 'The Affiliate Program');

define('TEXT_INFORMATION', 'You were logged out successfully.');
define('TEXT_INFORMATION_ERROR_1', 'You could not be logged out.');
define('TEXT_INFORMATION_ERROR_2', 'You were not logged in and can therefore not be logged out.');
?>