<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_VIPHONE_TITLE', 'Viphone');
  define('MODULE_BOXES_VIPHONE_DESCRIPTION', 'Access to the store through iPhone');
  define('MODULE_BOXES_VIPHONE_BOX_TITLE', 'osCommerce in iPhone');
  define('MODULE_BOXES_VIPHONE_MESSAGE', 'Access this store through your iPhone')
?>