<?php
/*
  $Id: ot_coupon.php,v 1.0 2006/04/05 Ingo <http://forums.oscommerce.de/index.php?showuser=36>

  Digistore v4.0,  Open Source E-Commerce Solutions
  http://www.digistore.co.nz

  Copyright (c) 2006 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ORDER_TOTAL_COUPON_TITLE', 'Coupon');
  define('MODULE_ORDER_TOTAL_COUPON_DESCRIPTION', 'Coupon');
  define('MODULE_ORDER_TOTAL_COUPON_ERROR_MIN_ORDER', 'The minimum value to use this coupon is');
?>