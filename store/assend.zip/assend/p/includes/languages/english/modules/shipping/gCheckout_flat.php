<?php
/*
  gCheckout_flat.php,  Advance Google Checkout BETA

  Advance Software 
  http://www.advancewebsoft.com

  Copyright (c) 2006 Advance Software

*/

define('GOOGLECHECKOUT_FLAT_TEXT_TITLE', 'Google Checkout Flat Rate');
define('GOOGLECHECKOUT_FLAT_TEXT_DESCRIPTION', 'Google Checkout Flat Rate');
?>
