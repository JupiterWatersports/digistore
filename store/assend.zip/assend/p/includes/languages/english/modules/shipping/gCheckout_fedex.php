<?php
/*
  gCheckout_fedex.php,  Advance Google Checkout BETA

  Advance Software 
  http://www.advancewebsoft.com

  Copyright (c) 2006 Advance Software

*/

define('GOOGLECHECKOUT_FEDEX_TEXT_TITLE', 'Google Checkout Federal Express');
define('GOOGLECHECKOUT_FEDEX_TEXT_DESCRIPTION', 'Federal Express<br /><br />You will need to have registered an account with FEDEX to use this module. Please see the README.TXT file for other requirements.');
?>
