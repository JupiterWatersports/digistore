<?php
define('MODULE_SHIPPING_FEDEX_WEB_SERVICES_TEXT_TITLE', 'FedEx');
define('MODULE_SHIPPING_FEDEX_WEB_SERVICES_TEXT_DESCRIPTION', '<h2>FedEx Web Services</h2><p>You will need to have an account with FedEx to use this module. <br /><br /> You will need to log into your account to apply for a Web Services Production Key.  <br /><br />Once you complete the form, FedEx will then display your key and a new Meter number for you to copy. Write it down!. They will then email the account holder with the password.  <br /><br />Once you login to FedEx <a href="https://www.fedex.com/wpor/web/jsp/drclinks.jsp?links=wss/production.html" target="_blank"><u>click here to get the key</a>.</u><br /></p>');
// eof
?>