<?php

define('MODULE_SHIPPING_LABEL_UPSWS_TITLE', "UPS Worldship XML Auto Import");
define('MODULE_SHIPPING_LABEL_UPSWS_DESCRIPTION', "Configuration for the <i>UPS Worldship XML auto import</i> contribution")
?>