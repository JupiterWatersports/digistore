<?php
/*
  $Id: ot_shipping.php 1739 2007-12-20 00:52:16Z hpdl $

  Digistore v4.0,  Open Source E-Commerce Solutions
  http://www.digistore.co.nz

  Copyright (c) 2003 osCommerce, http://www.oscommerce.com

  Released under the GNU General Public License
*/

  define('MODULE_ORDER_TOTAL_SHIPPING_TITLE', 'Shipping');
  define('MODULE_ORDER_TOTAL_SHIPPING_DESCRIPTION', 'Order Shipping Cost');

  define('FREE_SHIPPING_TITLE', 'No Shipping Charge for Lessons, Rentals, or Gift Certificates');
  define('FREE_SHIPPING_DESCRIPTION', '');
?>