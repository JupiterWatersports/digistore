<?php
/*
  $Id: easydebit.php,v 1.00 2005/09/20 19:57:15 ab Exp $

  easyDebit ePayment GmbH

  Copyright (c) 2005 easyDebit ePayment GmbH

  Released under the GNU General Public License
*/


  define('MODULE_PAYMENT_EASYDEBIT_TEXT_TITLE', 'Debit');
  define('MODULE_PAYMENT_EASYDEBIT_TEXT_DESCRIPTION', 'easyDebit I-Frame Integration');
  
  define('MODULE_PAYMENT_EASYDEBIT_ORDER_TITLE', 'Debit');
?>
