<?php

define('MODULE_SHIPPING_PPOSC_TEXT_TITLE', 'PostagePony Addon');
define('MODULE_SHIPPING_PPOSC_TEXT_DESCRIPTION', 'PostagePony Service<br /><br />You will need to have registered an account with PostagePony at <a href="http://www.postagepony.com/signup" target="_blank">http://www.postagepony.com/signup</a> to use this module<br /><br />PostagePony expects you to use pounds as weight measure for your products.');
define('MODULE_SHIPPING_PPOSC_TEXT_ERROR', 'An error occured with the PostagePony shipping calculations.<br />If you prefer to use USPS as your shipping method, please contact the store owner.');
?>
