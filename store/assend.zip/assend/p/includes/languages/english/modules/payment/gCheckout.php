<?php
/*
  gCheckout.php,  Advance Google Checkout BETA

  Advance Software 
  http://www.advancewebsoft.com

  Copyright (c) 2006 Advance Software

*/

  define('GOOGLECHECKOUT_TITLE', 'GoogleCheckout');
  define('GOOGLECHECKOUT_DESCRIPTION', 'Google Checkout Payment Module');
  define('GOOGLECHECKOUT_OR_USE', ' - or use - ');
  
?>
