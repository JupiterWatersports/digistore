<?php
/*
  $Id: free_download.php 1739 2007-12-20 00:52:16Z hpdl $

  Digistore v4.0,  Open Source E-Commerce Solutions
  http://www.digistore.co.nz

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_FREE_TEXT_TITLE', 'Free Downloads');
  define('MODULE_PAYMENT_FREE_TEXT_DESCRIPTION', 'Enable downloads for free products');
?>