<?php
/*
  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License

  Discount Code 2.9
  http://high-quality-php-coding.com/
*/

  define('MODULE_ORDER_TOTAL_DISCOUNT_TITLE', 'Discount Code');
  define('MODULE_ORDER_TOTAL_DISCOUNT_DESCRIPTION', 'Discount Code');
?>