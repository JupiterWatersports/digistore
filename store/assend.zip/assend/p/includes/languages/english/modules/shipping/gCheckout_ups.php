<?php
/*
  gCheckout_ups.php,  Advance Google Checkout BETA

  Advance Software 
  http://www.advancewebsoft.com

  Copyright (c) 2006 Advance Software

*/

define('GOOGLECHECKOUT_UPS_TEXT_TITLE', 'Google Checkout United Parcel Service');
define('GOOGLECHECKOUT_UPS_TEXT_DESCRIPTION', 'Google Checkout United Parcel Service');
define('GOOGLECHECKOUT_UPS_TEXT_OPT_GND', 'UPS Ground');
define('GOOGLECHECKOUT_UPS_TEXT_OPT_1DM', 'Next Day Air Early AM');
define('GOOGLECHECKOUT_UPS_TEXT_OPT_1DA', 'Next Day Air');
define('GOOGLECHECKOUT_UPS_TEXT_OPT_1DP', 'Next Day Air Saver');
define('GOOGLECHECKOUT_UPS_TEXT_OPT_2DM', '2nd Day Air Early AM');
define('GOOGLECHECKOUT_UPS_TEXT_OPT_3DS', '3 Day Select');
define('GOOGLECHECKOUT_UPS_TEXT_OPT_STD', 'Canada Standard');
define('GOOGLECHECKOUT_UPS_TEXT_OPT_XPR', 'Worldwide Express');
define('GOOGLECHECKOUT_UPS_TEXT_OPT_XDM', 'Worldwide Express Plus');
define('GOOGLECHECKOUT_UPS_TEXT_OPT_XPD', 'Worldwide Expedited');
?>
