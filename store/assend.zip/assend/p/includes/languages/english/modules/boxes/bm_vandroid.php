<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2010 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_BOXES_VANDROID_TITLE', 'vAndroid');
  define('MODULE_BOXES_VANDROID_DESCRIPTION', 'Access to the store through Android phone');
  define('MODULE_BOXES_VANDROID_BOX_TITLE', 'osCommerce in Android phone');
  define('MODULE_BOXES_VANDROID_MESSAGE', 'Access this store through your Android phone')
?>