<?php
/*
  $Id: percent.php,v 1.0 2003/09/04 01:48:08 dgw_ Exp $

  Digistore v4.0,  Open Source E-Commerce Solutions
  http://www.digistore.co.nz

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SHIPPING_PERCENT_TEXT_TITLE', 'Percent Rate');
define('MODULE_SHIPPING_PERCENT_TEXT_DESCRIPTION', 'Percent Rate');
define('MODULE_SHIPPING_PERCENT_TEXT_WAY', '');
define('MODULE_SHIPPING_PERCENT_TEXT_WEIGHT', 'Weight');
define('MODULE_SHIPPING_PERCENT_TEXT_AMOUNT', 'Amount');
?>
