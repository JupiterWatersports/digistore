<?php
/*
  $Id: sts_product_info.php,v 1.0 2005/11/03 23:09:49 Rigadin Exp $

  Digistore v4.0,  Open Source E-Commerce Solutions
  http://www.digistore.co.nz

  Copyright (c) 2005 osCommerce

  Released under the GNU General Public License
  * Module for STS v4 
*/

  define('MODULE_STS_PRODUCT_INFO_TITLE', 'Product info');
  define('MODULE_STS_PRODUCT_INFO_DESCRIPTION', 'Product info templates and content templates');
?>