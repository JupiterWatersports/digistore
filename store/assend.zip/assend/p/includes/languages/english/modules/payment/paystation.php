<?php
  define('MODULE_PAYMENT_PAYSTATION_TEXT_TITLE', 'Paystation Secure Credit Card Payment');
  define('MODULE_PAYMENT_PAYSTATION_TEXT_DESCRIPTION', 'Paystation real-time online credit card payments.<br /><br />
  Call 0800 PAYSTATION (0800 729 782) in New Zealand only<br /><br /><a href="http://www.paystation.co.nz" target="_blank">www.paystation.co.nz</a><br /><a href="https://www.paystation.co.nz/admin" target="_blank">www.paystation.co.nz/admin</a>');
  define('MODULE_PAYMENT_PAYSTATON_TEXT_CT', 'Card Type');
?>