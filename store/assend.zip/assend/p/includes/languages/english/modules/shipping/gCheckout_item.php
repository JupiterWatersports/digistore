<?php
/*
  gCheckout_item.php,  Advance Google Checkout BETA

  Advance Software 
  http://www.advancewebsoft.com

  Copyright (c) 2006 Advance Software

*/
define('GOOGLECHECKOUT_ITEM_TEXT_TITLE', 'Google Checkout Per Item');
define('GOOGLECHECKOUT_ITEM_TEXT_DESCRIPTION', 'Google Checkout Per Item');
?>
