<?php
/*
$Id: stormpay.php,v 1.39 2003/01/29 19:57:15 hpdl Exp $


Digistore v4.0,  Open Source E-Commerce Solutions
http://www.digistore.co.nz

Copyright (c) 2002 osCommerce

Released under the GNU General Public License
*/

define('MODULE_PAYMENT_STORMPAY_TEXT_TITLE', 'Stormpay');
define('MODULE_PAYMENT_STORMPAY_TEXT_DESCRIPTION', 'Stormpay');
?> 