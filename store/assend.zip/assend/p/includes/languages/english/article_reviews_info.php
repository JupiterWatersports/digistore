<?php
/*
  $Id: article_reviews_info.php, v1.0 2003/12/04 12:00:00 ra Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Review');
define('HEADING_TITLE', 'Review of ');
define('SUB_TITLE_ARTICLE', 'Article:');
define('SUB_TITLE_FROM', 'From:');
define('SUB_TITLE_DATE', 'Date:');
define('SUB_TITLE_REVIEW', 'Review:');
define('SUB_TITLE_RATING', 'Rating:');
define('TEXT_OF_5_STARS', '%s of 5 Stars');
?>
