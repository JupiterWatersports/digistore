<?php
/*
  $Id: coupon_german.php,v 1.0 2006/04/05 Ingo <http://forums.oscommerce.de/index.php?showuser=36>

  Digistore v4.0,  Open Source E-Commerce Solutions
  http://www.digistore.co.nz

  Copyright (c) 2006 osCommerce

  Released under the GNU General Public License
*/

  define('COUPON_BOX_HEADING', 'Coupon Code');
  define('COUPON_BOX_PLEASE_ENTER', 'Please enter your discount coupon code here:');
  define('COUPON_BOX_SORRY_CUSTOMER', 'Your discount coupon code was already used.');
  define('COUPON_BOX_SUCCESS_CUSTOMER', 'This discount coupon code is now active and will be used during checkout.');
  define('COUPON_BOX_PRE_SAVE', 'The coupon is noted.<br /> Please login <a href="' . tep_href_link(FILENAME_CREATE_ACCOUNT) . '"><b>HERE</b></a> o h�gase una nueva cuenta de cliente<a href="' . tep_href_link(FILENAME_LOGIN) . '"><b>Here</b></a> or an existing account to use this coupon.');
  define('COUPON_BOX_CODE_ACTIVE', 'Coupon code <br />is active');
  define('COUPON_BOX_CODE_WRONG', 'Coupon code is invalid.');
  define('COUPON_BOX_VALUE', 'Worth');

?>