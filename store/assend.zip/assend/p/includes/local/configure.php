<?php

/****************************************************** 
* Email Invoice 1.1.
* The values below are required by the email invoice mod.
* Author Contact: federicorodriguez911@gmail.com
******************************************************/

/**** Email Invoice File Definitions ****/
define('FILENAME_EMAIL_INVOICE', 'email_invoice.php');
define('FILENAME_ORDERS_INVOICE', 'invoice.php');

/**** Email Directory Definitions ****/
define('DIR_FS_ADMIN', '/home/jupiterk/domains/jupiterkiteboarding.com/public_html/store/assend/'); // absolute path required
define('EMAIL_INVOICE_DIR', 'email_invoice/');
define('INVOICE_TEMPLATE_DIR', 'templates/');

/*** End of Mod ***/

?>
