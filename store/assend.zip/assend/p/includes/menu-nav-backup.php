<nav id="menu2" class="menu">
<ul>
<li class="only-mobile no-menu"><a href="http://www.jupiterkiteboarding.com/">Home</a></li>


<li class="topheading has-submenu"><a href="main.php?catt=611">KITE</a>
<div class="sub-menu dropdown_6columns" >
    	<div class="featured column col-sm-2">
        <a class="hdline">FEATURED</a>
        <ul style="display:block; overflow:inherit;">
        <li><a href="<?php echo tep_href_link('newproducts.php?cat=kite'); ?>">New Products</a></li>
        <li><a href="<?php echo tep_href_link('sale.php?cat=kite'); ?>">Sale</a></li>
        </ul>
        </div>
		<div class="column has-submenu col-sm-2">
		<a class="hdline">Kites</a>
		<ul style="display:block;">
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[52]=trainer-kites-lessons'); ?>">Trainer Kites</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category%5B45%5D=Kitesurfing+Kites&brand%5B68%5D=Airush'); ?>">Airush</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category%5B45%5D=Kitesurfing+Kites&brand%5B10%5D=Cabrinha'); ?>">Cabrinha</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category%5B45%5D=Kitesurfing+Kites&brand%5B11%5D=North'); ?>">North</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category%5B45%5D=Kitesurfing+Kites&brand%5B35%5D=Wainman+Hawaii'); ?>">Wainman Hawaii</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category%5B45%5D=Kitesurfing+Kites&brand%5B135%5D=F-One'); ?>">F-One</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category%5B45%5D=Kitesurfing+Kites&brand%5B29%5D=Ozone'); ?>">Ozone</a></li>
        <li class="lessons"><a href="<?php echo tep_href_link('main.php?catt=611&category[578]=lessons'); ?>"><h3>Lessons</h3></a></li>
        </ul>
		</div>

        <div class="column has-submenu col-sm-2">
        <a class="hdline">Boards</a>
        <ul style="display:block;">
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[566]=twin-kiteboards'); ?>">Twin Tips</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[567]=kite-surfboards'); ?>">Kite Surfboards</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[680]=foil-boards'); ?>">Foil Boards</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[182]=pads-straps'); ?>">Pads &amp; Straps</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[206]=kiteboard-fins'); ?>">Fins</a></li>
        </ul>
        </div>

        <div class="column has-submenu col-sm-2">
        <a class="hdline">Harnesses</a>
        <ul style="display:block;">
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[568]=waist-harness'); ?>">Waist</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[569]=seat-harness'); ?>">Seat</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[255]=impact-vests'); ?>">Impact Vests</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[463]=harness-accessories'); ?>">Accessories</a></li>
        </ul>
        </div>
        
        <div class="column has-submenu col-sm-2 control-bars">
        <a class="hdline">Control Bars</a>
        <ul style="display:block;">
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[681]=complete-bars'); ?>">Complete Bars</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[614]=chicken-loop-lines'); ?>">Chicken Loop Lines</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[48]=replacement-line'); ?>">Replacement Lines</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[230]=safety-leashes'); ?>">Safety Leashes</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[615]=replacement-parts'); ?>">Parts</a></li> 
        </ul>
        </div>
        
        <div class="column has-submenu col-sm-2">
        <a class="hdline">Accessories</a>
        <ul style="display:block;">
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[66]=accessories-kite-board-bags'); ?>">Kite &amp; Board Bags</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[193]=helmets'); ?>">Helmets</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[224]=kite-pumps-'); ?>">Pumps</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[494]=kite-board-repair'); ?>">Kite/ Board Repair</a></li> 
		<li><a href="<?php echo tep_href_link('main.php?catt=611&category[502]=leading-edge'); ?>">Leading Edge</a></li> 
		<li><a href="<?php echo tep_href_link('main.php?catt=611&category[601]=struts-bladders'); ?>">Struts Bladders</a></li>
		<li><a href="<?php echo tep_href_link('main.php?catt=611&category[500]=valves'); ?>">Valves</a></li> 
        </ul>
        </div>
<span class="only-mobile no-menu" style="float:left;"><a style="color:#606060; font-weight:600; text-transform:uppercase; font-size:17px;" href="<?php echo tep_href_link('main.php?catt=611&category[578]=lessons'); ?>">Lessons</a></span>

	
</div>
</li>

<li class="topheading has-submenu"><a href="main.php?catt=612">PADDLE</a>
<div class="sub-menu dropdown_5columns">

<div class="featured column col-sm-2">
        <a class="hdline">FEATURED</a>
        <ul style="display:block; overflow:inherit;">
        <li><a href="<?php echo tep_href_link('newproducts.php?cat=paddle'); ?>">New Products</a></li>
        <li><a href="<?php echo tep_href_link('sale.php?cat=paddle'); ?>">Sale</a></li>
        </ul>
</div>

<div class="column has-submenu col-sm-2">
<a class="hdline">Boards</a>
<ul style="display:block;">
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[572]=around-paddleboards'); ?>">All Around</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[573]=surfing-paddleboards'); ?>">Surfing</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[571]=racing-touring-paddleboards'); ?>">Racing/Touring</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[603]=fishing-paddleboards'); ?>">Fishing</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[753]=foil-paddleboards'); ?>">Foil SUP</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[574]=inflatable-paddleboards'); ?>">Inflatable</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[586]=used-paddleboards'); ?>">Used Boards</a></li>
<li class="lessons"><a href="<?php echo tep_href_link('main.php?catt=612&category[588]=lessons-tours'); ?>"><h3>Lessons</h3></a></li>
<li class="lessons"><a href="<?php echo tep_href_link('main.php?catt=612&category[632]=rentals'); ?>"><h3>Rentals</h3></a></li>
</ul>
</div>

<div class="column has-submenu col-sm-2">
<a class="hdline">Paddles</a>
<ul style="display:block;">
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[473]=standard-paddles'); ?>">1 Piece</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[475]=2piece-adjustable-paddles'); ?>">2 Piece Adjustable</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[474]=3piece-adjustable-paddles'); ?>">3 Piece Adjustable</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[631]=racing-paddles'); ?>">Racing Paddles</a></li>
</ul>
</div>

<div class="column has-submenu col-sm-2 accessories">
<a class="hdline">Accessories</a>
<ul style="display:block;">
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[638]=board-accessories'); ?>">Board Accessories</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[437]=board-paddle-bags'); ?>">Board/Paddle Bags</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[623]=paddle-protection'); ?>">Board &amp; Paddle Protection</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[641]=coolers'); ?>">Coolers</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[487]=fins'); ?>">Fins</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[438]=leashes'); ?>">Leashes</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[563]=pfds'); ?>">Life Jackets</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[624]=repair-products'); ?>">Repair Products</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[626]=traction-pads'); ?>">Traction Pads</a></li>
</ul>
</div>

<div class="column has-submenu col-sm-2 racks">
<a class="hdline">Racks</a>
<ul style="display:block;">
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[634]=ceiling-rack'); ?>">Ceiling</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[557]=wall-racks'); ?>">Wall</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[556]=roof-racks'); ?>">Car Roof Rack</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[606]=rack-accessories'); ?>">Car Roof Rack Accessories</a></li>
</ul>
</div>
<span class="only-mobile no-menu" style="float:left; width:100%;"><a style="color:#606060; font-weight:600; text-transform:uppercase; font-size:17px;" href="<?php echo tep_href_link('main.php?catt=612&category[588]=lessons-tours'); ?>">Lessons</a></span>
<span class="only-mobile no-menu" style="float:left;  width:100%;"><a style="color:#606060; font-weight:600; text-transform:uppercase; font-size:17px;" href="<?php echo tep_href_link('main.php?catt=612&category[632]=rentals'); ?>">Rentals</a></span>
</div>
</li>


<li class="topheading has-submenu"><a href="main.php?catt=200">WAKE</a>
<div class="sub-menu dropdown_4columns">

<div class="featured column col-sm-2">
        <a class="hdline">FEATURED</a>
        <ul style="display:block; overflow:inherit;">
        <li><a href="<?php echo tep_href_link('newproducts.php?cat=wake'); ?>">New Products</a></li>
        <li><a href="<?php echo tep_href_link('sale.php?cat=wake'); ?>">Sale</a></li>
        </ul>
</div>

<div class="column has-submenu col-sm-2">
<a class="hdline">Boards</a>
<ul style="display:block;">
	<li><a href="<?php echo tep_href_link('main.php?catt=200&category[560]=mens-wakeboards'); ?>">Mens</a></li>
	<li><a href="<?php echo tep_href_link('main.php?catt=200&category[561]=womens-wakeboard'); ?>">Womens</a></li>
	<li><a href="<?php echo tep_href_link('main.php?catt=200&category[643]=kids-wakeboards'); ?>">Kids</a></li>
	<li><a href="<?php echo tep_href_link('main.php?catt=200&category[562]=wakeboard-combos'); ?>">Combo</a></li>
	<li><a href="<?php echo tep_href_link('main.php?catt=200&category[761]=wake-foils'); ?>">Wake Foils</a></li>
	<li><a href="<?php echo tep_href_link('main.php?catt=200&category[708]=wakesurfers'); ?>">Wakesurfers</a></li>
	<li><a href="<?php echo tep_href_link('main.php?catt=200&category[281]=wakeskates'); ?>">Wakeskates</a></li>
	<li class="lessons"><a href="<?php echo tep_href_link('main.php?catt=200&category[558]=lessons'); ?>"><h3>Lessons</h3></a></li>
</ul>
</div>

<div class="column has-submenu col-sm-2">
<a class="hdline">Bindings</a>
<ul style="display:block;">
<li><a href="<?php echo tep_href_link('main.php?catt=200&category[466]=mens-bindings'); ?>">Mens</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=200&category[465]=womens-bindings'); ?>">Womens</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=200&category[467]=kids-bindings'); ?>">Kids</a></li>
</ul>
</div>

<div class="column has-submenu col-sm-2 racks">
<a class="hdline">Accessories</a>
<ul style="display:block;">
<li><a href="<?php echo tep_href_link('main.php?catt=200&category[210]=life-jackets-impact-vests'); ?>">Life Jackets &amp; Impact Vests</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=200&category[211]=wakeboard-rope'); ?>">Wakeboard Rope</a></li>
</ul>
</div>
<span class="only-mobile no-menu" style="float:left; width:100%;"><a style="color:#606060; font-weight:600; text-transform:uppercase; font-size:17px;" href="<?php echo tep_href_link('main.php?catt=200&category[558]=lessons'); ?>">Lessons</a></span>
</div>
</li>

<li class="topheading has-submenu"><a href="main.php?catt=627">SURF</a>
<ul class=" sub-menu dropdown_1columns surfing">
<li><a href="<?php echo tep_href_link('main.php?catt=627&category[646]=boards'); ?>">Boards</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=627&category[764]=foil-boards'); ?>">Foil Boards</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=627&category[645]=replacement-fins'); ?>">Fins</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=627&category[628]=traction-pads'); ?>">Traction Pads</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=627&category[629]=board-bags'); ?>">Board Bags</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=627&category[648]=leashes'); ?>">Leashes</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=627&category[553]=rescue-sleds'); ?>">Rescue Sleds</a></li>
</ul>
</li>


<li class="topheading has-submenu"><a href="main.php?catt=67">WATER WEAR</a>
<ul class="sub-menu dropdown_1columns wwear">
<li><a href="<?php echo tep_href_link('main.php?catt=67&category[316]=wetsuits'); ?>">Wetsuits</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=67&category[318]=wetsuit-tops'); ?>">Wetsuit Tops</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=67&category[760]=jackets-neo-jackets'); ?>">Jackets/ Neo Jackets</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=67&category[302]=rash-guards'); ?>">Rash Guards</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=67&category[651]=booties'); ?>">Booties</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=67&category[388]=swim-shorts'); ?>">Swim Shorts</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=67&category[297]=hats'); ?>">Hats</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=67&category[304]=sunglasses'); ?>">Sunglasses</a></li> 

<li><a href="<?php echo tep_href_link('main.php?catt=67&category[461]=gloves'); ?>">Gloves</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=67&category[595]=hydration-pack-back'); ?>">Back Pack Hydration Pack</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=67&category[596]=hydration-pack-waist-style'); ?>">Waist Hydration Pack</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=67&category[552]=waterproof-packs'); ?>">Waterproof Packs</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=67&category[570]=sunscreen'); ?>">Sunscreen</a></li>  
</ul>
</li>

<li class="topheading has-submenu"><a href="main.php?catt=551">GOPRO</a>
<ul class="sub-menu dropdown_1columns gopro">
<li><a href="<?php echo tep_href_link('main.php?catt=551&category[598]=gopro-hero-cameras'); ?>">Cameras</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=551&category[599]=gopro-hero-mounts'); ?>">Mounts</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=551&category[600]=gopro-hero-accessories'); ?>">Accessories</a></li>       
</ul>
</li>

<li class="topheading has-submenu"><a href="main.php?catt=582">SKATE</a>
<ul class="sub-menu dropdown_1columns skate">
<li><a href="<?php echo tep_href_link('main.php?catt=582&category[650]=electric-skateboards'); ?>">Electric Skateboards</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=582&category[575]=longboards-skateboards'); ?>">Longboards &amp; Skateboards</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=582&category[555]=balance-boards'); ?>">Balance Boards</a></li>

<li><a href="<?php echo tep_href_link('main.php?catt=582&category[564]=land-paddles'); ?>">Land Paddle</a></li>
</ul>
</li>

<li class="topheading has-submenu"><a href="main.php?catt=549">WINDSURF</a>
<ul class="sub-menu dropdown_1columns wndsrf">
<li><a href="<?php echo tep_href_link('main.php?catt=549&category[589]=windsurfing-complete'); ?>">Complete Kit</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=549&category[590]=windsurfing-mast-bases'); ?>">Mast Bases</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=549&category[591]=windsurfing-mast-extensions'); ?>">Mase Extensions</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=549&category[592]=windsurfing-cleats-lines'); ?>">Cleats &amp; Lines</a></li>
</ul>
</li>

<li class="no-menu"><a href="<?php echo tep_href_link('sale'); ?>">SALE</a></li>

<li class="only-mobile no-menu"><a href="<?php echo tep_href_link('gift-certificates-c-559.html') ?>">Gift Certificates</a></li>

</ul>
</nav>

<nav id="menu3" class="menu">
<ul>
<li class="only-mobile no-menu"><a href="http://www.jupiterkiteboarding.com/">Home</a></li>


<li class="topheading has-submenu"><a>KITE</a>
<div class="sub-menu dropdown_6columns" >
    	<div class="featured column col-sm-2">
        <a class="hdline">FEATURED</a>
        <ul style="display:block; overflow:inherit;">
        <li><a href="<?php echo tep_href_link('newproducts.php?cat=kite'); ?>">New Products</a></li>
        <li><a href="<?php echo tep_href_link('sale.php?cat=kite'); ?>">Sale</a></li>
        </ul>
        </div>
		<div class="column has-submenu col-sm-2">
		<a class="hdline">Kites</a>
		<ul style="display:block;">
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[52]=trainer-kites-lessons'); ?>">Trainer Kites</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category%5B45%5D=Kitesurfing+Kites&brand%5B68%5D=Airush'); ?>">Airush</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category%5B45%5D=Kitesurfing+Kites&brand%5B10%5D=Cabrinha'); ?>">Cabrinha</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category%5B45%5D=Kitesurfing+Kites&brand%5B11%5D=North'); ?>">North</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category%5B45%5D=Kitesurfing+Kites&brand%5B35%5D=Wainman+Hawaii'); ?>">Wainman Hawaii</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category%5B45%5D=Kitesurfing+Kites&brand%5B135%5D=F-One'); ?>">F-One</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category%5B45%5D=Kitesurfing+Kites&brand%5B29%5D=Ozone'); ?>">Ozone</a></li>
        <li class="lessons"><a href="<?php echo tep_href_link('main.php?catt=611&category[578]=lessons'); ?>"><h3>Lessons</h3></a></li>
        </ul>
		</div>

        <div class="column has-submenu col-sm-2">
        <a class="hdline">Boards</a>
        <ul style="display:block;">
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[566]=twin-kiteboards'); ?>">Twin Tips</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[567]=kite-surfboards'); ?>">Kite Surfboards</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[680]=foil-boards'); ?>">Foil Boards</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[182]=pads-straps'); ?>">Pads &amp; Straps</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[206]=kiteboard-fins'); ?>">Fins</a></li>
        </ul>
        </div>

        <div class="column has-submenu col-sm-2">
        <a class="hdline">Harnesses</a>
        <ul style="display:block;">
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[568]=waist-harness'); ?>">Waist</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[569]=seat-harness'); ?>">Seat</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[255]=impact-vests'); ?>">Impact Vests</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[463]=harness-accessories'); ?>">Accessories</a></li>
        </ul>
        </div>
        
        <div class="column has-submenu col-sm-2 control-bars">
        <a class="hdline">Control Bars</a>
        <ul style="display:block;">
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[681]=complete-bars'); ?>">Complete Bars</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[614]=chicken-loop-lines'); ?>">Chicken Loop Lines</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[48]=replacement-line'); ?>">Replacement Lines</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[230]=safety-leashes'); ?>">Safety Leashes</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[615]=replacement-parts'); ?>">Parts</a></li> 
        </ul>
        </div>
        
        <div class="column has-submenu col-sm-2">
        <a class="hdline">Accessories</a>
        <ul style="display:block;">
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[66]=accessories-kite-board-bags'); ?>">Kite &amp; Board Bags</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[193]=helmets'); ?>">Helmets</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[224]=kite-pumps-'); ?>">Pumps</a></li>
        <li><a href="<?php echo tep_href_link('main.php?catt=611&category[494]=kite-board-repair'); ?>">Kite/ Board Repair</a></li> 
		<li><a href="<?php echo tep_href_link('main.php?catt=611&category[502]=leading-edge'); ?>">Leading Edge</a></li> 
		<li><a href="<?php echo tep_href_link('main.php?catt=611&category[601]=struts-bladders'); ?>">Struts Bladders</a></li>
		<li><a href="<?php echo tep_href_link('main.php?catt=611&category[500]=valves'); ?>">Valves</a></li> 
        </ul>
        </div>
<span class="only-mobile no-menu" style="float:left;"><a style="color:#606060; font-weight:600; text-transform:uppercase; font-size:17px;" href="<?php echo tep_href_link('main.php?catt=611&category[578]=lessons'); ?>">Lessons</a></span>

	
</div>
</li>

<li class="topheading has-submenu"><a>PADDLE</a>
<div class="sub-menu dropdown_5columns">

<div class="featured column col-sm-2">
        <a class="hdline">FEATURED</a>
        <ul style="display:block; overflow:inherit;">
        <li><a href="<?php echo tep_href_link('newproducts.php?cat=paddle'); ?>">New Products</a></li>
        <li><a href="<?php echo tep_href_link('sale.php?cat=paddle'); ?>">Sale</a></li>
        </ul>
</div>

<div class="column has-submenu col-sm-2">
<a class="hdline">Boards</a>
<ul style="display:block;">
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[572]=around-paddleboards'); ?>">All Around</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[573]=surfing-paddleboards'); ?>">Surfing</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[571]=racing-touring-paddleboards'); ?>">Racing/Touring</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[603]=fishing-paddleboards'); ?>">Fishing</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[753]=foil-paddleboards'); ?>">Foil SUP</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[574]=inflatable-paddleboards'); ?>">Inflatable</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[586]=used-paddleboards'); ?>">Used Boards</a></li>
<li class="lessons"><a href="<?php echo tep_href_link('main.php?catt=612&category[588]=lessons-tours'); ?>"><h3>Lessons</h3></a></li>
<li class="lessons"><a href="<?php echo tep_href_link('main.php?catt=612&category[632]=rentals'); ?>"><h3>Rentals</h3></a></li>
</ul>
</div>

<div class="column has-submenu col-sm-2">
<a class="hdline">Paddles</a>
<ul style="display:block;">
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[473]=standard-paddles'); ?>">1 Piece</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[475]=2piece-adjustable-paddles'); ?>">2 Piece Adjustable</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[474]=3piece-adjustable-paddles'); ?>">3 Piece Adjustable</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[631]=racing-paddles'); ?>">Racing Paddles</a></li>
</ul>
</div>

<div class="column has-submenu col-sm-2 accessories">
<a class="hdline">Accessories</a>
<ul style="display:block;">
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[638]=board-accessories'); ?>">Board Accessories</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[437]=board-paddle-bags'); ?>">Board/Paddle Bags</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[623]=paddle-protection'); ?>">Board &amp; Paddle Protection</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[641]=coolers'); ?>">Coolers</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[487]=fins'); ?>">Fins</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[438]=leashes'); ?>">Leashes</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[563]=pfds'); ?>">Life Jackets</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[624]=repair-products'); ?>">Repair Products</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[626]=traction-pads'); ?>">Traction Pads</a></li>
</ul>
</div>

<div class="column has-submenu col-sm-2 racks">
<a class="hdline">Racks</a>
<ul style="display:block;">
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[634]=ceiling-rack'); ?>">Ceiling</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[557]=wall-racks'); ?>">Wall</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[556]=roof-racks'); ?>">Car Roof Rack</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=612&category[606]=rack-accessories'); ?>">Car Roof Rack Accessories</a></li>
</ul>
</div>
<span class="only-mobile no-menu" style="float:left; width:100%;"><a style="color:#606060; font-weight:600; text-transform:uppercase; font-size:17px;" href="<?php echo tep_href_link('main.php?catt=612&category[588]=lessons-tours'); ?>">Lessons</a></span>
<span class="only-mobile no-menu" style="float:left;  width:100%;"><a style="color:#606060; font-weight:600; text-transform:uppercase; font-size:17px;" href="<?php echo tep_href_link('main.php?catt=612&category[632]=rentals'); ?>">Rentals</a></span>
</div>
</li>


<li class="topheading has-submenu"><a >WAKE</a>
<div class="sub-menu dropdown_4columns">

<div class="featured column col-sm-2">
        <a class="hdline">FEATURED</a>
        <ul style="display:block; overflow:inherit;">
        <li><a href="<?php echo tep_href_link('newproducts.php?cat=wake'); ?>">New Products</a></li>
        <li><a href="<?php echo tep_href_link('sale.php?cat=wake'); ?>">Sale</a></li>
        </ul>
</div>

<div class="column has-submenu col-sm-2">
<a class="hdline">Boards</a>
<ul style="display:block;">
	<li><a href="<?php echo tep_href_link('main.php?catt=200&category[560]=mens-wakeboards'); ?>">Mens</a></li>
	<li><a href="<?php echo tep_href_link('main.php?catt=200&category[561]=womens-wakeboard'); ?>">Womens</a></li>
	<li><a href="<?php echo tep_href_link('main.php?catt=200&category[643]=kids-wakeboards'); ?>">Kids</a></li>
	<li><a href="<?php echo tep_href_link('main.php?catt=200&category[562]=wakeboard-combos'); ?>">Combo</a></li>
	<li><a href="<?php echo tep_href_link('main.php?catt=200&category[761]=wake-foils'); ?>">Wake Foils</a></li>
	<li><a href="<?php echo tep_href_link('main.php?catt=200&category[708]=wakesurfers'); ?>">Wakesurfers</a></li>
	<li><a href="<?php echo tep_href_link('main.php?catt=200&category[281]=wakeskates'); ?>">Wakeskates</a></li>
	<li class="lessons"><a href="<?php echo tep_href_link('main.php?catt=200&category[558]=lessons'); ?>"><h3>Lessons</h3></a></li>
</ul>
</div>

<div class="column has-submenu col-sm-2">
<a class="hdline">Bindings</a>
<ul style="display:block;">
<li><a href="<?php echo tep_href_link('main.php?catt=200&category[466]=mens-bindings'); ?>">Mens</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=200&category[465]=womens-bindings'); ?>">Womens</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=200&category[467]=kids-bindings'); ?>">Kids</a></li>
</ul>
</div>

<div class="column has-submenu col-sm-2 racks">
<a class="hdline">Accessories</a>
<ul style="display:block;">
<li><a href="<?php echo tep_href_link('main.php?catt=200&category[210]=life-jackets-impact-vests'); ?>">Life Jackets &amp; Impact Vests</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=200&category[211]=wakeboard-rope'); ?>">Wakeboard Rope</a></li>
</ul>
</div>
<span class="only-mobile no-menu" style="float:left; width:100%;"><a style="color:#606060; font-weight:600; text-transform:uppercase; font-size:17px;" href="<?php echo tep_href_link('main.php?catt=200&category[558]=lessons'); ?>">Lessons</a></span>
</div>
</li>

<li class="topheading has-submenu"><a >SURF</a>
<ul class=" sub-menu dropdown_1columns surfing">
<li><a href="<?php echo tep_href_link('main.php?catt=627&category[646]=boards'); ?>">Boards</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=627&category[764]=foil-boards'); ?>">Foil Boards</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=627&category[645]=replacement-fins'); ?>">Fins</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=627&category[628]=traction-pads'); ?>">Traction Pads</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=627&category[629]=board-bags'); ?>">Board Bags</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=627&category[648]=leashes'); ?>">Leashes</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=627&category[553]=rescue-sleds'); ?>">Rescue Sleds</a></li>
</ul>
</li>


<li class="topheading has-submenu"><a>WATER WEAR</a>
<ul class="sub-menu dropdown_1columns wwear">
<li><a href="<?php echo tep_href_link('main.php?catt=67&category[316]=wetsuits'); ?>">Wetsuits</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=67&category[318]=wetsuit-tops'); ?>">Wetsuit Tops</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=67&category[760]=jackets-neo-jackets'); ?>">Jackets/ Neo Jackets</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=67&category[302]=rash-guards'); ?>">Rash Guards</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=67&category[651]=booties'); ?>">Booties</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=67&category[388]=swim-shorts'); ?>">Swim Shorts</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=67&category[297]=hats'); ?>">Hats</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=67&category[304]=sunglasses'); ?>">Sunglasses</a></li> 

<li><a href="<?php echo tep_href_link('main.php?catt=67&category[461]=gloves'); ?>">Gloves</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=67&category[595]=hydration-pack-back'); ?>">Back Pack Hydration Pack</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=67&category[596]=hydration-pack-waist-style'); ?>">Waist Hydration Pack</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=67&category[552]=waterproof-packs'); ?>">Waterproof Packs</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=67&category[570]=sunscreen'); ?>">Sunscreen</a></li>  
</ul>
</li>

<li class="topheading has-submenu"><a >GOPRO</a>
<ul class="sub-menu dropdown_1columns gopro">
<li><a href="<?php echo tep_href_link('main.php?catt=551&category[598]=gopro-hero-cameras'); ?>">Cameras</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=551&category[599]=gopro-hero-mounts'); ?>">Mounts</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=551&category[600]=gopro-hero-accessories'); ?>">Accessories</a></li>       
</ul>
</li>

<li class="topheading has-submenu"><a >SKATE</a>
<ul class="sub-menu dropdown_1columns skate">
<li><a href="<?php echo tep_href_link('main.php?catt=582&category[650]=electric-skateboards'); ?>">Electric Skateboards</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=582&category[575]=longboards-skateboards'); ?>">Longboards &amp; Skateboards</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=582&category[555]=balance-boards'); ?>">Balance Boards</a></li>

<li><a href="<?php echo tep_href_link('main.php?catt=582&category[564]=land-paddles'); ?>">Land Paddle</a></li>
</ul>
</li>

<li class="topheading has-submenu"><a >WINDSURF</a>
<ul class="sub-menu dropdown_1columns wndsrf">
<li><a href="<?php echo tep_href_link('main.php?catt=549&category[589]=windsurfing-complete'); ?>">Complete Kit</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=549&category[590]=windsurfing-mast-bases'); ?>">Mast Bases</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=549&category[591]=windsurfing-mast-extensions'); ?>">Mase Extensions</a></li>
<li><a href="<?php echo tep_href_link('main.php?catt=549&category[592]=windsurfing-cleats-lines'); ?>">Cleats &amp; Lines</a></li>
</ul>
</li>

<li class="no-menu"><a href="<?php echo tep_href_link('sale'); ?>">SALE</a></li>

<li class="only-mobile no-menu"><a href="<?php echo tep_href_link('gift-certificates-c-559.html') ?>">Gift Certificates</a></li>

</ul>
</nav>

