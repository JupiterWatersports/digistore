<?php //008fe
// MagneticOne
// Copyright (c) 2007 MagneticOne.com <contact@magneticone.com>
// All rights reserved
// 
// 
// PLEASE READ  THE FULL TEXT OF SOFTWARE LICENSE AGREEMENT IN THE "license.txt"
// FILE PROVIDED WITH THIS DISTRIBUTION. THE AGREEMENT TEXT IS ALSO AVAILABLE
// AT THE FOLLOWING URL: http://www.magneticone.com/store/license.php
// 
// THIS  AGREEMENT  EXPRESSES  THE  TERMS  AND CONDITIONS ON WHICH YOU MAY USE
// THIS SOFTWARE   PROGRAM   AND  ASSOCIATED  DOCUMENTATION   THAT  MAGNETICONE
// (hereinafter  referred to as "THE AUTHOR") IS FURNISHING  OR MAKING
// AVAILABLE TO YOU WITH  THIS  AGREEMENT  (COLLECTIVELY,  THE  "SOFTWARE").
// PLEASE   REVIEW   THE  TERMS  AND   CONDITIONS  OF  THIS  LICENSE AGREEMENT
// CAREFULLY   BEFORE   INSTALLING   OR  USING  THE  SOFTWARE.  BY INSTALLING,
// COPYING   OR   OTHERWISE   USING   THE   SOFTWARE,  YOU  AND  YOUR  COMPANY
// (COLLECTIVELY,  "YOU")  ARE  ACCEPTING  AND AGREEING  TO  THE TERMS OF THIS
// LICENSE   AGREEMENT.   IF  YOU    ARE  NOT  WILLING   TO  BE  BOUND BY THIS
// AGREEMENT, DO  NOT INSTALL OR USE THE SOFTWARE.  VARIOUS   COPYRIGHTS   AND
// OTHER   INTELLECTUAL   PROPERTY   RIGHTS    PROTECT   THE   SOFTWARE.  THIS
// AGREEMENT IS A LICENSE AGREEMENT THAT GIVES  YOU  LIMITED  RIGHTS   TO  USE
// THE  SOFTWARE   AND  NOT  AN  AGREEMENT  FOR SALE OR FOR  TRANSFER OF TITLE.
// THE AUTHOR RETAINS ALL RIGHTS NOT EXPRESSLY GRANTED BY THIS AGREEMENT.
// 
if(!extension_loaded('ionCube Loader')){$__oc=strtolower(substr(php_uname(),0,3));$__ln='/ioncube/ioncube_loader_'.$__oc.'_'.substr(phpversion(),0,3).(($__oc=='win')?'.dll':'.so');$__oid=$__id=realpath(ini_get('extension_dir'));$__here=dirname(__FILE__);if(strlen($__id)>1&&$__id[1]==':'){$__id=str_replace('\\','/',substr($__id,2));$__here=str_replace('\\','/',substr($__here,2));}$__rd=str_repeat('/..',substr_count($__id,'/')).$__here.'/';$__i=strlen($__rd);while($__i--){if($__rd[$__i]=='/'){$__lp=substr($__rd,0,$__i).$__ln;if(file_exists($__oid.$__lp)){$__ln=$__lp;break;}}}@dl($__ln);}else{die('The file '.__FILE__." is corrupted.\n");}if(function_exists('_il_exec')){return _il_exec();}echo('Site error: the file <b>'.__FILE__.'</b> requires the ionCube PHP Loader '.basename($__ln).' to be installed by the site administrator.');exit(199);
?>
4+oV51OpySoP6ShZO8Haxt0aETMuzGmaedA6iyfk34GTSpVNOP5uQm6hmmjy8kY7K9FQNoZXTALu
j8vAElo4+NLaBy/abosUqyFnYm2DYzYMt5lRnPYcf6RghTxdpbTypJHknIuF05hmFRW/AcW86eNZ
0KyP71o3h+0fl7Kqd09hNTf8t8oeq9b/wzssJRo/1rbnBTrCyFs5N1nYyQAGLTNjvY+DJ8WuH8gO
W1oIM51xdO1RFpvhgCTqQdTXy+wzUlIo+kseOK6SGod1GaaM23ADju0qgFz8ALgX26q/Hu1GyWv/
+A7HEUmny13/smI10ioNLXpkY4nYRV/EROmavWLD+iMyG8+/KjPjtKRZw9sqJP+HzYO5q1viWDpd
ou1jVGBSmoSud8IDpRNkwCK12EAYWdomzJVKnUQ8gvxbKSeK2Ibp2BMFsFl87aP3Uze19uXdvt7T
V2MeL3DTAKtOgfhXCR6GkI6a/XgXluW//2O4WuuAwkB9jpbhSazbBRiou3Mkt8ezKbWYce7GQNSA
lX6D58PzhDwj/H5t3MYX641HaCf7QvORwMoMJFoLlkftwhDlHNvV2cGp5CmmafJ48XsEov1StJHG
Kj9cOq20yTIIuThcOqWeQS5w+A4sPTGER8RH0EmSIR8nwsTlS0hUdQxOaqbqucUya1vnX5RCFjn1
tr4q4Gk1KA8URgEGqvk1AtaefhBTOtCbpgtHS5kJWmk8Q0Da6wQUFjmJUKJnHo2V0rOiRcyW6aTU
VVoLSSR9VjPsbL1/CidfwrD7mVcdMu2AqG5IGkXHzXC/ydxgNW5Sp51EXA8KbaremzKmK8nM5oEF
rDSjNTC4GncRXcPL/Q8NoKMn